import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-speisekarte',
  templateUrl: './speisekarte.component.html',
  styleUrls: ['./speisekarte.component.css']
})
export class SpeisekarteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
